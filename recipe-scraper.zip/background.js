var get_page = function(tab)   {
   return fetch(tab.url)
      .then(response => response.text())
      .then((data) => {
        return data
        } )
      .catch(function (err) {
            // There was an error
            console.warn('Something went wrong.', err);
        });
  }

var extract_text = function(doc) {
    text = doc.querySelectorAll("[id^='tasty-recipes-']")
    return text

}

var parse_page = function(html)  {
    var doc = new DOMParser().parseFromString(html, "text/html");

    var links = extract_text(doc)

    console.log(links)
    text = []

    links.forEach( item  => {
        text.push(item.innerHTML)
    }
    )
    text = text.join('<br>')
    console.log(text)
    return text
}

var generate_page = function(text) {
    console.log(text)
    win = window.open()
    win.document.write(text)
}

var run = function(tab){
    get_page(tab)
    .then(html => parse_page(html))
    .then(parsed => generate_page(parsed) )
    }

// Called when the user clicks on the browser action.
chrome.browserAction.onClicked.addListener(function(tab) {
   run(tab)
  });